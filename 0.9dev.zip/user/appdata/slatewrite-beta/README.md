# SlateWrite [Public Beta]
## Introduction
Hello! Thank you for installing SlateWrite!

Please refer to the guide below to see how to use SlateWrite.

### Editing documents
Documents can be edited as if using Microsoft Word or any other word processor. Text can be copy/pasted from webpages to preserve formatting, and spreadsheets can be copy/pasted from Word or Excel.

Media (images/videos/sounds) can be uploaded using the buttons along the top.

Look through the buttons along the top to see what tools are available.

*Please be advised that this is still a beta copy*