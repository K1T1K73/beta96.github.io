// Welcome to Beta96 Professional Edition!

// About our project

Our project is based on Windows 96 and is currently in development. We strive to make our system user-friendly and intuitive, so please report any bugs to the developers via private messages in Telegram and Discord, and we'll fix them in future releases. :)

// How to use this system

The system is made just for you, use it as you need.

// How this maked, what progams i used

I used Paint.NET, Firefox Developer Edition. I used programming languages ​​such as CSS, JavaScript, HTML, Python.




// Answers to the questions:

- Is it possible to download Discord here?

Very hard, but possible

- Is it possible to download Telegram here?

You can use the web-version with iframe/x-frame/framebrokers

- How to delete this welcome file?

Delete the C:/system/startup/readme.link file and delete the readme.txt in the desktop


Many thanks to Darvin Flintston, Alix Glebov, and the entire Frutiger Aero community for participating in this project.

Thanks for reading! :)