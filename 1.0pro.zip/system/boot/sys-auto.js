// system reserved
// make your own JS file to create code for startup

delete localStorage['social_mv.lock'];
w96.WRT.runFile("C:/system/boot/helloworld2");
